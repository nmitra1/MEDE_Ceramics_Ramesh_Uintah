#include <aba_for_c.h>  //to use FOR_NAME, which is equaivalent to umat_
#include "FastMatrixMW.cc"
#include "GFMS_fullMW.cc"
#include "Matrix3x3MW.cc"
#include "MGEOSMW.cc"
#include "MEDECeramIntRameshV3.cc"
#include "UMATIRTWM.cc"
#include "Vector3MW.cc"


extern "C" void FOR_NAME(vumat) (int  *nblock, int *ndir, int *nshr, 
                             int *nstatev, int *nfieldv, int *nprops, 
                             int *lanneal, double *stepTime, double *totalTime, 
                             double *dt, double *cmname, void *coordMp, double *charLength,
                             double props[], void *density, 
                             double *strainInc, void *relSpinInc,
                             double *tempOld, void *stretchOld, double *defgradOld, 
                             void *fieldOld, double *stressOld, double *stateOld, 
                             double *enerInternOld, double *enerInelasOld,
                             double *tempNew, void *stretchNew, double *defgradNew, void *fieldNew,
                             double *stressNew, double *stateNew, double *enerInternNew, double *enerInelasNew)
{
	   
    IRTWM_vumat_stressUpdate(nblock, ndir, nshr, 
                            nstatev, nfieldv, nprops, 
                            lanneal, stepTime, totalTime, 
                            dt, cmname, coordMp, charLength,
                            props, density, 
                            strainInc, relSpinInc,
                            tempOld, stretchOld, defgradOld, 
                            fieldOld, stressOld, stateOld, 
                            enerInternOld, enerInelasOld,
                            tempNew, stretchNew, defgradNew, fieldNew,
                            stressNew, stateNew, enerInternNew, enerInelasNew);

}
  
