#include <aba_for_c.h>  //to use FOR_NAME, which is equaivalent to umat_
#include "FastMatrixMW.cc"
#include "GFMS_fullMW.cc"
#include "Matrix3x3MW.cc"
#include "MGEOSMW.cc"
#include "MEDECeramIntRameshV3.cc"
#include "UMATIRTWM.cc"
#include "Vector3MW.cc"

extern "C" void FOR_NAME(umat) (double STRESS[6], double STATEV[], double DDSDDE[6][6],
                             double *SSE, double *SPD, double *SCD, double *RPL,
                             double DDSDDT[6], double DRPLDE[6], double *DRPLDT,
                             const double STRAN[6], const double DSTRAN[6], const double TIME[2],
                             const double *DTIME, double *TEMP, double *DTEMP,
                             const double *PREDEF, const double *DPRED, const double *CMNAME,
                             const int *NDI, const int *NSHR, const int *NTENS, const int *NSTATV,
                             const double PROPS[PTR_NUM_MAT_PARAMS], const int *NPROPS, const double COORDS[3],
                             const double DROT[3][3], double *PNEWDT, const double *CELENT,
                             const double DFGRD0[3][3], const double DFGRD1[3][3],
                             const int *NOEL, const int *NPT, const int *LAYER,
                             const int *KSPT, const int *KSTEP, const int *KINC)
{
	
   if ((*KSTEP==1 || *KSTEP==0) && (*KINC==1||*KINC==0)){
      *SCD=PROPS[73];//The tempture is initialized as reference temp
      IRTWM_umat_getInitialValuesNoProps(*NSTATV, STATEV);
   }      
   std::ofstream amorphizationIni;
   
   double ptemp = *SCD;
   IRTWM_umat_stressUpdate(STRESS, STATEV, DDSDDE,
                             SSE, SPD, SCD, RPL,
                             DDSDDT, DRPLDE, DRPLDT,
                             STRAN, DSTRAN, TIME,
                             DTIME, &ptemp, DTEMP,
                             PREDEF, DPRED, CMNAME,
                             NDI, NSHR, NTENS, NSTATV,
                             PROPS, NPROPS, COORDS,
                             DROT, PNEWDT, CELENT,
                             DFGRD0, DFGRD1,
                             NOEL, NPT,LAYER,
                             KSPT, KSTEP, KINC, amorphizationIni); 
    *SCD = ptemp;
}
  
