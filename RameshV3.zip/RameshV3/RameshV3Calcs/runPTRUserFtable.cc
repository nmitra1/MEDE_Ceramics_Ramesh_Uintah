/*
 * This project constitutes a work of the United States Government and is not
 * subject to domestic copyright protection under 17 USC § 105.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

#include "PortableTongeRamesh.h"
#include "PortableMieGruneisenEOSTemperature.h"
#include "GFMS_full.h"

// C++ IO
#include <iostream>             // std::cout
#include <iomanip>
#include <cmath>
#include <fstream>              // std::ofstream
#include <stdexcept>            // std::runtime_error
#include <string>
#include <sstream>
#include <vector>

Matrix3x3 calcF(double t){
  double f11 = 1.0;
  double f12 = t*1.0e3;
  double f13 = 0.0;
  double f21 = 0.0;
  double f22 = 1.0;
  double f23 = 0.0;
  double f31 = 0.0;
  double f32 = 0.0 ;
  double f33 = 1.0;
  return Matrix3x3(f11, f12, f13, f21, f22, f23, f31, f32, f33);
}

Matrix3x3 calcL(double t){
  Matrix3x3 F=calcF(t);
  Matrix3x3 Finv=F.inverse();
  double l11 = 0.0;
  double l12 = 1.0e3;
  double l13 = 0.0;
  double l21 = 0.0;
  double l22 = 0.0;
  double l23 = 0.0;
  double l31 = 0.0;
  double l32 = 0.0 ;
  double l33 = 0.0;
  Matrix3x3 Fdot(l11, l12, l13, l21, l22, l23, l31, l32, l33);
  Matrix3x3 lmat=Fdot*Finv;
  return lmat;
}

// Run tests that exersize every function by directly calling the function:
int main(){

  std::cout << "Material Parameters should be in: MatParams.inp"
            << "\n with one parameter per line"
            << std::endl;
  std::cout << "The desired deformation history should be in FGrad.inp"
            << "\nThe formatting is:\n"
            << "t,f11,f12,f13,f21,f22,f23,f31,f32,f33"
            << std::endl;
  std::cout << "output is written to: PTR_userInputDefRate.txt"
            << std::endl;


  // Just assign material properties for now:
  PTR::CMData cmData;
  //ModelData;
  PTR::ModelData initalData;
    // TRFlags:;
  PTR::Flags TRFlags;
  TRFlags.implicit = false;
  TRFlags.allowNoShear = false;
  TRFlags.allowNoTension = false;
  TRFlags.artificialViscosity = false;
  TRFlags.artificialViscosityHeating = false;
  TRFlags.setStressToZero = false;
  TRFlags.with_color = false;
  TRFlags.doErosion = false;

    // ArtificialViscosity
  PTR::ArtificialViscosity artVisc;
  artVisc.coeff1 = 0.4;
  artVisc.coeff2 = 4.0;

  // flawDistributionData
  PTR::flawDistributionData flawDistData;
  //flawDistData.type = 'pareto';
  // Not used in a single element driver;
  flawDistData.randomMethod = 6 ;
  flawDistData.randomSeed = 4;
  flawDistData.randomizeDist = false;
  // Not used with a Pareto distribution of flaws;
  flawDistData.stdFlawSize = 10.0e-6; //Not used with a Pareto distribution;
  flawDistData.meanFlawSize = 10.0e-6; //Not used with a Pareto distribution;
  // Only makes sense in a continuum problem where flaw density is a function of postion;
  flawDistData.useSizeField = false;
  //flawDistData.sizeFilename = 'N/A';
  flawDistData.useEtaField = false;
  //flawDistData.etaFilename = 'N/A';

  // BrittleDamageData
  PTR::BrittleDamageData brittleData;
  // unused/not maintined options:;
  brittleData.printDamage = false;
  // Used for controling global timestep based on damage rate:;
  brittleData.useDamageTimeStep = false;
  brittleData.dt_increaseFactor = 10.0;

  // granularPlasticityData
  PTR::granularPlasticityData gpData;
  gpData.JGP_loc          = 200.0;

  // All of these are reset
  gpData.GFMSsolParams.absToll = 1.0e-12;
  gpData.GFMSsolParams.relToll = 1.0e-8;
  gpData.GFMSsolParams.maxIter = 10;
  gpData.GFMSsolParams.maxLevels = 4;

  gpData.GPModelType             = PTR::SingleSurface;

  // parse the MatParams:
  const int numMatParams(58);
  std::ifstream is("MatParams.inp");
  if(!is.good()){
    throw std::runtime_error("File open operation failed");
  }
  int valuesRead=0;
  float matParamVec[numMatParams];
  std::string line;
  while(std::getline(is,line) && valuesRead<numMatParams){
    std::istringstream iss(line);
    iss >> matParamVec[valuesRead];
    if(!iss){
      std::cerr << "Bad line: \n"
                << line
                << std::endl;
      is.close();
      throw std::runtime_error("Error while reading from matParam file");
    }
    valuesRead++;
  }
  is.close();
  if(valuesRead != numMatParams){
    std::stringstream msg;
    msg << "Incorrect number of values read while parsing MatParams.inp"
	<< '\n'
	<< "Expected: " << numMatParams << '\t' << "read: " << valuesRead;
    throw std::runtime_error(msg.str());
  }

  // Repeat the input values:
  std::cout << "Finshed reading the material parameter input:"
            << std::endl;

  for (int i=0; i<numMatParams; ++i){
    std::cout << matParamVec[i]
              << std::endl;
  }

  cmData.C_0 = matParamVec[0];
  cmData.S_1 = matParamVec[1];
  cmData.S_2 = matParamVec[2];
  cmData.S_3 = matParamVec[3];
  cmData.C_v = matParamVec[4];
  cmData.Gamma_0  = matParamVec[5];
  cmData.N_points = ( matParamVec[6] > 0.0) ?
    (int)floor(matParamVec[6]+0.5) : 50;
  cmData.J_min    = matParamVec[7];
  cmData.theta_0  = matParamVec[8];
  double rho_orig = matParamVec[9];

  PTR::PortableMieGruneisenEOSTemperature d_eos(cmData);
  initalData.tauDev = matParamVec[10];
  initalData.Bulk   = d_eos.computeIsentropicBulkModulus(rho_orig,
							 rho_orig,
							 cmData.theta_0
							 );
  initalData.Alpha        = matParamVec[11];
  initalData.FlowStress   = matParamVec[12];
  initalData.K            = matParamVec[13];
  initalData.timeConstant = matParamVec[14];

  TRFlags.useDamage             = matParamVec[15] > 0.0;
  TRFlags.usePlasticity         = matParamVec[16] > 0.0;
  TRFlags.useGranularPlasticity = matParamVec[17] > 0.0;
  TRFlags.useOldStress          = matParamVec[18] > 0.0;

  flawDistData.binBias     = matParamVec[19];
  flawDistData.exponent    = matParamVec[20];
  flawDistData.flawDensity = matParamVec[21];
  flawDistData.maxFlawSize = matParamVec[22];
  flawDistData.minFlawSize = matParamVec[23];
  flawDistData.numCrackFamilies = (int)floor(0.5+matParamVec[24]);

  brittleData.KIc            = matParamVec[25];
  brittleData.alpha          = matParamVec[26];
  brittleData.cgamma         = matParamVec[27];
  brittleData.mu             = matParamVec[28];
  brittleData.phi            = matParamVec[29];
  brittleData.criticalDamage = matParamVec[30];
  brittleData.maxDamage      = matParamVec[31];
  brittleData.doFlawInteraction = matParamVec[32] > 0.0;
  brittleData.incInitialDamage  = matParamVec[33] > 0.0;
  brittleData.usePlaneStrain    = matParamVec[34] > 0.0;
  brittleData.maxDamageInc      = matParamVec[35];

  gpData.A                = matParamVec[36];
  gpData.B                = matParamVec[37];
  gpData.Pc               = matParamVec[38];
  gpData.Pe               = matParamVec[39];
  gpData.alpha_e          = matParamVec[40];
  gpData.timeConstant     = matParamVec[41];
  gpData.yeildSurfaceType = matParamVec[42] > 1.9 && matParamVec[42] < 2.1 ? 2 : 1;
  gpData.GPModelType            = matParamVec[43] < 0.5 ?
    PTR::TwoSurface : PTR::SingleSurface;
  gpData.GFMSmatParams.bulkMod  = initalData.Bulk;
  gpData.GFMSmatParams.shearMod = initalData.tauDev;
  gpData.GFMSmatParams.m0       = matParamVec[44];
  gpData.GFMSmatParams.m1       = matParamVec[45];
  gpData.GFMSmatParams.m2       = matParamVec[46];
  gpData.GFMSmatParams.p0       = matParamVec[47];
  gpData.GFMSmatParams.p1       = matParamVec[48];
  gpData.GFMSmatParams.p2       = matParamVec[49];
  gpData.GFMSmatParams.p3       = matParamVec[50];
  gpData.GFMSmatParams.p4       = matParamVec[51];
  gpData.GFMSmatParams.a1       = matParamVec[52];
  gpData.GFMSmatParams.a2       = matParamVec[53];
  gpData.GFMSmatParams.a3       = matParamVec[54];
  gpData.GFMSmatParams.beta     = matParamVec[55];
  gpData.GFMSmatParams.psi      = matParamVec[56];
  if(matParamVec[57] > 1.9){
    gpData.GFMSmatParams.J3Type   = GFMS::WilliamWarnke;
  } else if(matParamVec[57] > 0.9){
    gpData.GFMSmatParams.J3Type   = GFMS::Gudehus;
  } else {
    gpData.GFMSmatParams.J3Type   = GFMS::DruckerPrager;
  }
  gpData.GFMSmatParams.relaxationTime = gpData.timeConstant;

  // Read the user defined solution parameters:
    is.open("SolParam.inp");
  getline(is,line);
  std::istringstream iss2(line);
  double delT;
  iss2 >> delT;
  if(!iss2){
    std::cerr << "Bad line: \n"
              << line
              << std::endl;
    is.close();
    throw std::runtime_error("Error while reading from solParam file");
  }
  // Now read the rest of the solution parameters:
  float solParamVec[NUM_SOL_PARAM];
  valuesRead=0;
  while(std::getline(is,line) && valuesRead<NUM_SOL_PARAM){
    std::istringstream iss(line);
    iss >> solParamVec[valuesRead];
    if(!iss){
      std::cerr << "Bad line: \n"
                << line
                << std::endl;
      is.close();
      throw std::runtime_error("Error while reading from solParam file");
    }
    valuesRead++;
  }
  is.close();

  // Repeat the input values:
  std::cout << "Finshed reading the solution parameter input:"
            << std::endl;
  std::cout << "delT:\t" << delT << std::endl;
  for (int i=0; i<NUM_SOL_PARAM; ++i){
    std::cout << solParamVec[i]
              << std::endl;
  }

  gpData.GFMSsolParams = GFMS::unpackSolutionParameters(solParamVec);

  // Read the deformation history:
  is.open("DeformationGradient.inp");
  std::vector<double> inputTime;
  std::vector<double> F11;
  std::vector<double> F12;
  std::vector<double> F13;
  std::vector<double> F21;
  std::vector<double> F22;
  std::vector<double> F23;
  std::vector<double> F31;
  std::vector<double> F32;
  std::vector<double> F33;
  double tmin(0.0),tmax(0.0);
  while(std::getline(is,line)){
    std::istringstream iss(line);
    double t,f11,f12,f13,f21,f22,f23,f31,f32,f33;
    iss >> t
	>> f11 >> f12 >> f13
	>> f21 >> f22 >> f23
	>> f31 >> f32 >> f33;
    if(!iss){
      std::cerr << "Bad line: \n"
                << line
                << std::endl;
      is.close();
      throw std::runtime_error("Error while reading from DefRate file");
    }
    tmin = std::min(t,tmin);
    tmax = std::max(t,tmax);
    inputTime.push_back(t);
    F11.push_back(f11);
    F12.push_back(f12);
    F13.push_back(f13);
    F21.push_back(f21);
    F22.push_back(f22);
    F23.push_back(f23);
    F31.push_back(f31);
    F32.push_back(f32);
    F33.push_back(f33);
  }
  is.close();

  std::cout << "Finshed reading the rate of deformation input:"
            << std::endl;

  std::cout.setf(std::ios::dec|std::ios::left|std::ios::scientific);
  std::cout << std::setw(20) << "t"
            << std::setw(20) << "F11"
            << std::setw(20) << "F12"
            << std::setw(20) << "F13"
            << std::setw(20) << "F21"
            << std::setw(20) << "F22"
            << std::setw(20) << "F23"
            << std::setw(20) << "F31"
            << std::setw(20) << "F32"
            << std::setw(20) << "F33"
            << std::endl;

  for (std::vector<double>::size_type i=0; i<inputTime.size(); ++i){
    std::cout << std::setw(20) << std::setprecision(12) << inputTime[i]
              << std::setw(20) << std::setprecision(12) << F11[i]
              << std::setw(20) << std::setprecision(12) << F12[i]
      	      << std::setw(20) << std::setprecision(12) << F13[i]
              << std::setw(20) << std::setprecision(12) << F21[i]
              << std::setw(20) << std::setprecision(12) << F22[i]
      	      << std::setw(20) << std::setprecision(12) << F23[i]
              << std::setw(20) << std::setprecision(12) << F31[i]
              << std::setw(20) << std::setprecision(12) << F32[i]
              << std::setw(20) << std::setprecision(12) << F33[i]
              << std::endl;
  }

  int nsteps = (int)floor((tmax-tmin)/delT + 0.5);

  // initalize history variables:
  // initalize the flaw bins (TongeRamesh.cc:1759)
  double smin = flawDistData.minFlawSize;
  double smax = flawDistData.maxFlawSize;
  double ln = smax-smin;
  int nBins = flawDistData.numCrackFamilies;
  double binWidth = ln/((double)nBins);
  double eta = flawDistData.flawDensity;
  double a = flawDistData.exponent;
  std::vector<double> lVec(nBins);
  std::vector<double> lVec_new(nBins);
  std::vector<double> NVec(nBins);
  std::vector<double> sVec(nBins);
  for (int i=0; i<nBins; ++i){
    double s        = smax - (0.5*i)*binWidth;
    double pdfValue = a * pow(smin, a) * pow(s, -a-1.0) /
      (1-pow(smin/smax,a));
    sVec[i]  = s;
    lVec[i]  = 0.0;
    lVec_new[i] = 0.0;
    NVec[i]  = eta*pdfValue*binWidth;
  }

  Matrix3x3 fOld(true);
  Matrix3x3 fnew(true);
  Matrix3x3 Lnew(false);
  Matrix3x3 Dnew(false);

  Matrix3x3 bElBar=fOld*fOld.transpose();
  Matrix3x3 stress;
  Matrix3x3 stress_qs;

  Vector3 pVel(0.0,0.0,0.0);
  Vector3 dx(1.0e-6,1.0e-6,1.0e-6);
  Vector3 waveSpeed(1.0,1.0,1.0);
  double pGPJ_old = 1.0;
  double RoomTemperature = cmData.theta_0;
  double pTemperature    = cmData.theta_0;
  double pVolume_new     = dx.x()*dx.y()*dx.z();
  double pMass           = rho_orig * pVolume_new;
  double SpecificHeat    = cmData.C_v;
  double pDamage         = 0.0;
  double K               = initalData.K;
  double flow            = initalData.FlowStress;
  //Output
  double pGP_strain      = 0.0;
  double pPlasticStrain  = 0.0;
  double pPlasticEnergy  = 0.0;
  double pDamage_new     = 0.0;
  double pGPJ            = 1.0;
  double pGP_energy      = 0.0;
  double pEnergy_new     = 0.0;
  double damage_dt       = 1.0e2;
  double p_q             = 0.0;
  double se              = 0.0;
  double pdTdt           = 0.0;
  double pepsV           = 0.0;
  double pgam            = 0.0;
  double pepsV_qs        = 0.0;
  double pgam_qs         = 0.0;

  int pLocalized      = 0;
  long long pParticleID     = 13465489;
  long long totalLocalizedParticle = 0;
  int pLocalized_new      = 0;

  std::ofstream ofs ("GranularFlow_userInputDefRate.txt", std::ofstream::trunc);
  ofs.setf(std::ios::dec|std::ios::left|std::ios::scientific);
  ofs << std::setw(20) << "t"
      << std::setw(20) << "F11"
      << std::setw(20) << "F12"
      << std::setw(20) << "F13"
      << std::setw(20) << "F21"
      << std::setw(20) << "F22"
      << std::setw(20) << "F23"
      << std::setw(20) << "F31"
      << std::setw(20) << "F32"
      << std::setw(20) << "F33"
      << std::setw(20) << "L11"
      << std::setw(20) << "L12"
      << std::setw(20) << "L13"
      << std::setw(20) << "L21"
      << std::setw(20) << "L22"
      << std::setw(20) << "L23"
      << std::setw(20) << "L31"
      << std::setw(20) << "L32"
      << std::setw(20) << "L33"
      << std::setw(20) << "D11"
      << std::setw(20) << "D12"
      << std::setw(20) << "D13"
      << std::setw(20) << "D21"
      << std::setw(20) << "D22"
      << std::setw(20) << "D23"
      << std::setw(20) << "D31"
      << std::setw(20) << "D32"
      << std::setw(20) << "D33"
      << std::setw(20) << "bElBar11"
      << std::setw(20) << "bElBar12"
      << std::setw(20) << "bElBar13"
      << std::setw(20) << "bElBar21"
      << std::setw(20) << "bElBar22"
      << std::setw(20) << "bElBar23"
      << std::setw(20) << "bElBar31"
      << std::setw(20) << "bElBar32"
      << std::setw(20) << "bElBar33"
      << std::setw(20) << "sigma_11"
      << std::setw(20) << "sigma_12"
      << std::setw(20) << "sigma_13"
      << std::setw(20) << "sigma_21"
      << std::setw(20) << "sigma_22"
      << std::setw(20) << "sigma_23"
      << std::setw(20) << "sigma_31"
      << std::setw(20) << "sigma_32"
      << std::setw(20) << "sigma_33"
      << std::setw(20) << "sigma_qs_11"
      << std::setw(20) << "sigma_qs_12"
      << std::setw(20) << "sigma_qs_13"
      << std::setw(20) << "sigma_qs_21"
      << std::setw(20) << "sigma_qs_22"
      << std::setw(20) << "sigma_qs_23"
      << std::setw(20) << "sigma_qs_31"
      << std::setw(20) << "sigma_qs_32"
      << std::setw(20) << "sigma_qs_33"
      << std::setw(20) << "pGP_strain"
      << std::setw(20) << "pGPJ"
      << std::setw(20) << "pGP_energy"
      << std::setw(20) << "D"
      << std::setw(20) << "pdTdt"
      << std::setw(20) << "pTemp"
      << std::setw(20) << "se"
      << std::setw(20) << "epsV_p"
      << std::setw(20) << "gamma_p"
      << std::setw(20) << "epsV_p_qs"
      << std::setw(20) << "gamma_p_qs"
      << std::endl;


  const Matrix3x3 identity(true);
  unsigned int defGradRef(0);
  for (int i=0; i<nsteps; ++i){
    double t=i*delT+tmin;
    // Compute fnew:
    while(inputTime[defGradRef+1]<=(t+delT)
	  && (defGradRef+1)<inputTime.size()){
      ++defGradRef;
    }
    double frac = (t-inputTime[defGradRef])/
      (inputTime[defGradRef+1] - inputTime[defGradRef]);
    fnew.set(0,0, (1.0-frac)*F11[defGradRef] + (frac)*F11[defGradRef+1]);
    fnew.set(0,1, (1.0-frac)*F12[defGradRef] + (frac)*F12[defGradRef+1]);
    fnew.set(0,2, (1.0-frac)*F13[defGradRef] + (frac)*F13[defGradRef+1]);
    
    fnew.set(1,0, (1.0-frac)*F21[defGradRef] + (frac)*F21[defGradRef+1]);
    fnew.set(1,1, (1.0-frac)*F22[defGradRef] + (frac)*F22[defGradRef+1]);
    fnew.set(1,2, (1.0-frac)*F23[defGradRef] + (frac)*F23[defGradRef+1]);

    fnew.set(2,0, (1.0-frac)*F31[defGradRef] + (frac)*F31[defGradRef+1]);
    fnew.set(2,1, (1.0-frac)*F32[defGradRef] + (frac)*F32[defGradRef+1]);
    fnew.set(2,2, (1.0-frac)*F33[defGradRef] + (frac)*F33[defGradRef+1]);

    // Compute Lnew=(f_inc-I)/delT;
    Matrix3x3 finc = fnew*fOld.inverse();
    Lnew = (finc-identity)/delT;
    pdTdt = 0.0;
    PTR::ComputeStressTensorInnerLoop(
                                      TRFlags,
                                      initalData,
                                      flawDistData,
                                      brittleData,
                                      gpData,
                                      artVisc,
                                      &d_eos,
                                      fOld,
                                      fnew,
                                      Lnew,
                                      &Dnew,
                                      &bElBar,
                                      &stress,
                                      &stress_qs,
                                      pVel,
                                      dx,
                                      &waveSpeed,
                                      pGPJ_old,
                                      RoomTemperature,
                                      pTemperature,
                                      rho_orig,
                                      pVolume_new,
                                      pMass,
                                      SpecificHeat,
                                      pDamage,
                                      K,
                                      flow,
                                      delT,
                                      &pGP_strain,
                                      &pPlasticStrain,
                                      &pPlasticEnergy,
                                      &pDamage_new,
                                      &pGPJ,
                                      &pGP_energy,
                                      &pEnergy_new,
                                      &damage_dt,
                                      &p_q,
                                      &se,
                                      &pdTdt,
                                      &pepsV,
                                      &pgam,
                                      &pepsV_qs,
                                      &pgam_qs,
                                      pLocalized,
                                      pParticleID,
                                      &totalLocalizedParticle,
                                      &pLocalized_new,
                                      &lVec,
                                      &NVec,
                                      &sVec,
                                      &lVec_new
                                      );
    // copy output to input:
    pDamage = pDamage_new;
    pGPJ_old = pGPJ;
    pTemperature += pdTdt*delT;
    fOld=fnew;
    for(std::vector<double>::size_type j=0; j<lVec_new.size(); ++j){
      lVec[j] = lVec_new[j];
    }
    std::cout << "t=\t" << t << std::endl;
    // output the results:
    ofs << std::setw(20) << std::setprecision(12) << t;
    // Deformation gradient
    for (int j=0; j<3; ++j){
      for (int k=0; k<3; ++k){
        ofs << std::setw(20) << std::setprecision(12) << fnew.get(j,k);
      }
    }

    // Velocity gradient:
    for (int j=0; j<3; ++j){
      for (int k=0; k<3; ++k){
        ofs << std::setw(20) << std::setprecision(12) << Lnew.get(j,k);
      }
    }

    // Deformation rate:
    for (int j=0; j<3; ++j){
      for (int k=0; k<3; ++k){
        ofs << std::setw(20) << std::setprecision(12) << Dnew.get(j,k);
      }
    }

    // bElBar:
    for (int j=0; j<3; ++j){
      for (int k=0; k<3; ++k){
        ofs << std::setw(20) << std::setprecision(12) << bElBar.get(j,k);
      }
    }

    // Cauchy Stress:
    for (int j=0; j<3; ++j){
      for (int k=0; k<3; ++k){
        ofs << std::setw(20) << std::setprecision(12) << stress.get(j,k);
      }
    }

    // QS Stress for GFMS:
    for (int j=0; j<3; ++j){
      for (int k=0; k<3; ++k){
        ofs << std::setw(20) << std::setprecision(12) << stress_qs.get(j,k);
      }
    }
    
    ofs << std::setw(20) << std::setprecision(12) << pGP_strain;
    ofs << std::setw(20) << std::setprecision(12) << pGPJ;
    ofs << std::setw(20) << std::setprecision(12) << pGP_energy;
    ofs << std::setw(20) << std::setprecision(12) << pDamage;
    ofs << std::setw(20) << std::setprecision(12) << pdTdt;
    ofs << std::setw(20) << std::setprecision(12) << pTemperature;
    ofs << std::setw(20) << std::setprecision(12) << se;
    ofs << std::setw(20) << std::setprecision(12) << pepsV;
    ofs << std::setw(20) << std::setprecision(12) << pgam;
    ofs << std::setw(20) << std::setprecision(12) << pepsV_qs;
    ofs << std::setw(20) << std::setprecision(12) << pgam_qs;
    ofs << std::endl;
  }

  return 0;
}
