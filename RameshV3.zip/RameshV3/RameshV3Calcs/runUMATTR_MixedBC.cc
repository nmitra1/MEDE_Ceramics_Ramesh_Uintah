/*
 * This project constitutes a work of the United States Government and is not
 * subject to domestic copyright protection under 17 USC § 105.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

#include "PTR_defs.h"
#include "UMATTR.h"

#include "PortableTongeRamesh.h"
#include "FastMatrix.h"

// C++ IO
#include <iostream>             // std::cout
#include <iomanip>
#include <cmath>
#include <fstream>              // std::ofstream
#include <stdexcept>            // std::runtime_error
#include <string>
#include <sstream>
#include <vector>

// Run tests that exersize every function by directly calling the function:
int main(int argc, char* argv[]){
  std::string mixedBCFileName("MixedBC.inp");
  std::string matParamInputFileName("taggedMatParams.inp");
  std::string outputFileName("UMATTR_MixedBC_output.txt");
  switch (argc){
  // case 1:
  //   break;
  case 4:
    outputFileName = std::string(argv[3]);
    // fall through to next argument:
  case 3:
    matParamInputFileName = std::string(argv[2]);
    // fall through to next argument:
  case 2:
    mixedBCFileName = std::string(argv[1]);
    // fall through to display the file names to be used:
  case 1:
    std::cout << "Number of arguments: " << argc-1 << "\n"
              << "Boundary Conditions: " << mixedBCFileName << "\n"
              << "Material Parameters: " << matParamInputFileName << "\n"
              << "and Output: " << outputFileName << std::endl;
    break;
  default:
    throw std::runtime_error("Unreconized number of arguments, expected BoundaryConditionFileName MaterialParameterFileName outputFileName");
    break;
  }
  
  //////////////////// Read material parameters //////////////////////////
  double matParam[PTR_NUM_MAT_PARAMS] = {};
  PTR::parseMatParamData(matParam, matParamInputFileName);
  for (int i=0; i<PTR_NUM_MAT_PARAMS; ++i){
    std::cout << std::setw(40) << std::left << std::string(PTR_MatParamNames[i])
              << std::setw(20) << std::right << matParam[i] << std::endl;
  }
  std::cout << "done outputting material parameters" << std::endl;
  ///////////////// Done reading material parameters /////////////////////////
  const int numFlawBins = static_cast<int>(std::floor(matParam[13]+0.5));
  int nstatev           = PTR_FLAWHIST_OFFSET+3*numFlawBins;
  ///////////////// Initalize history variables //////////////////////////////
  std::vector<double> histVar(nstatev, 0.0);
  std::cout << "PTR_FLAWHIST_OFFSET=\t" << PTR_FLAWHIST_OFFSET << std::endl;
  std::cout << "histVarSize=\t" << histVar.size() << std::endl;
  char **histVarNames;
  histVarNames = new char*[nstatev];
  for (int i=0; i<nstatev; ++i){
    histVarNames[i] = new char[80];
  }
  std::vector<int> intData(nstatev,0);
  PTR_umat_register(nstatev, "varname", histVarNames,intData.data(),histVar.data());
  PTR_umat_register(nstatev, "initialvalue", histVarNames,intData.data(),histVar.data());
  ///////////////// done initalizing history variables ////////////////////
  for (int i=0; i<nstatev; ++i){
    std::cout << std::setw(20) << std::left << std::string(histVarNames[i])
              << std::setw(20) << std::right << histVar[i] << std::endl;
  }
  std::cout << "done outputting initial values for history variables" << std::endl;
  ///////////////// Read boundary condition input //////////////////////////
  double delT;
  double dx_ave;
  std::vector<int> calcEpsComp(6,0);
  std::ifstream is(mixedBCFileName.c_str());
  std::string line;
  std::getline(is,line);
  std::istringstream iss(line);
  iss >> delT;
  iss >> dx_ave;
  for (int i=0; i<6; ++i){
    iss >> calcEpsComp[i];
  }
  if(! (iss && delT>0) ){
    is.close();
    std::ostringstream msg;
    msg << "Error reading delT and BC from: " << mixedBCFileName << "\n"
        << "The expected format is: \n"
        << "delT dx_ave calcEps11 calcEps22 calcEps33 calcEps23 calcEps13 calcEps12";
    throw std::runtime_error( msg.str());
  }
  std::vector<int> calcEpsComIndex;
  calcEpsComIndex.reserve(8);
  for (int i=0; i<6; ++i){
    if(calcEpsComp[i]) calcEpsComIndex.push_back(i);
  }
  const int numStrainUnknown(calcEpsComIndex.size());
  std::vector<double> inputTime;
  std::vector<double> BC11;
  std::vector<double> BC22;
  std::vector<double> BC33;
  std::vector<double> BC23;
  std::vector<double> BC13;
  std::vector<double> BC12;
  double tmin(0.0),tmax(0.0);
  while(std::getline(is,line)){
    std::istringstream iss(line);
    double t,bc11,bc22,bc33,bc23,bc13,bc12;
    iss >> t >> bc11 >> bc22 >> bc33 >> bc23 >> bc13 >> bc12;
    if(!iss){
      std::cerr << "Bad line: \n"
                << line
                << std::endl;
      is.close();
      throw std::runtime_error("Error while reading from DefRate file");
    }
    tmin = std::min(t,tmin);
    tmax = std::max(t,tmax);
    inputTime.push_back(t);
    BC11.push_back(bc11);
    BC22.push_back(bc22);
    BC33.push_back(bc33);
    BC23.push_back(bc23);
    BC13.push_back(bc13);
    BC12.push_back(bc12);
  }
  is.close();

  std::cout << "Finshed reading the rate of deformation input:"
            << std::endl;
  ///////////////// Done reading boundary condition file /////////////
  std::cout.setf(std::ios::dec|std::ios::left|std::ios::scientific);
  std::cout << std::setw(20) << "t"
            << std::setw(20) << (calcEpsComp[0] == 0 ? "D11" : "Sigma11")
            << std::setw(20) << (calcEpsComp[1] == 0 ? "D22" : "Sigma22")
            << std::setw(20) << (calcEpsComp[2] == 0 ? "D33" : "Sigma33")
            << std::setw(20) << (calcEpsComp[3] == 0 ? "D23" : "Sigma23")
            << std::setw(20) << (calcEpsComp[4] == 0 ? "D13" : "Sigma13")
            << std::setw(20) << (calcEpsComp[5] == 0 ? "D12" : "Sigma12")
            << std::endl;

  for (std::vector<double>::size_type i=0; i<inputTime.size(); ++i){
    std::cout << std::setw(20) << std::setprecision(12) << inputTime[i]
              << std::setw(20) << std::setprecision(12) << BC11[i]
              << std::setw(20) << std::setprecision(12) << BC22[i]
              << std::setw(20) << std::setprecision(12) << BC33[i]
              << std::setw(20) << std::setprecision(12) << BC23[i]
              << std::setw(20) << std::setprecision(12) << BC13[i]
              << std::setw(20) << std::setprecision(12) << BC12[i]
              << std::endl;
  }

  //////////////////// Start time stepping loop ////////////////////
  int nsteps = (int)floor((tmax-tmin)/delT + 0.5);
  double stress[6] = {};
  double ddsdde[6][6] = {};
  double sse = 0.0;
  double spd = 0.0;
  double scd = 0.0;
  double rpl = 0.0;
  double ddsddt[6] = {};
  double drplde[6] = {};
  double drpldt = 0.0;
  double strain[6] = {};
  double dstrain[6] = {};
  double time[2] = {};
  double temp = 294.0;
  double dtemp = 0.0;
  double predef = 0.0;
  double dpred  = 0.0;
  double cmname = 0.0;
  int ndi  = 3;
  int nshr = 3;
  int ntens = 6;
  int nprops = PTR_NUM_MAT_PARAMS;
  double coords[3] = {0.0,0.0,0.0};
  double drot[3][3];
  drot[0][0] = 1.0;
  drot[0][1] = 0.0;
  drot[0][2] = 0.0;
  drot[1][0] = 0.0;
  drot[1][1] = 1.0;
  drot[1][2] = 0.0;
  drot[2][0] = 0.0;
  drot[2][1] = 0.0;
  drot[2][2] = 1.0;
  double pnewdt = 0.0;
  double celent = dx_ave;
  double dfgrd0[3][3];
  dfgrd0[0][0] = 1.0;
  dfgrd0[0][1] = 0.0;
  dfgrd0[0][2] = 0.0;
  dfgrd0[1][0] = 1.0;
  dfgrd0[1][1] = 1.0;
  dfgrd0[1][2] = 0.0;
  dfgrd0[2][0] = 0.0;
  dfgrd0[2][1] = 0.0;
  dfgrd0[2][2] = 1.0;
  double dfgrd1[3][3];
  dfgrd1[0][0] = 1.0;
  dfgrd1[0][1] = 0.0;
  dfgrd1[0][2] = 0.0;
  dfgrd1[1][0] = 1.0;
  dfgrd1[1][1] = 1.0;
  dfgrd1[1][2] = 0.0;
  dfgrd1[2][0] = 0.0;
  dfgrd1[2][1] = 0.0;
  dfgrd1[2][2] = 1.0;
  int noel  = 0;
  int npt   = 0;
  int layer = 0;
  int kspt  = 0;
  int kstep = 0;
  int kinc  = 0;

  std::ofstream ofs (outputFileName.c_str(), std::ofstream::trunc);
  ofs.setf(std::ios::dec|std::ios::left|std::ios::scientific);
  ofs << std::setw(20) << "t"
      << std::setw(20) << "stress11"
      << std::setw(20) << "stress22"
      << std::setw(20) << "stress33"
      << std::setw(20) << "stress12"
      << std::setw(20) << "stress13"
      << std::setw(20) << "stress23"
      << std::setw(20) << "strain11"
      << std::setw(20) << "strain22"
      << std::setw(20) << "strain33"
      << std::setw(20) << "strain12"
      << std::setw(20) << "strain13"
      << std::setw(20) << "strain23"
      << std::setw(20) << "dstrain11"
      << std::setw(20) << "dstrain22"
      << std::setw(20) << "dstrain33"
      << std::setw(20) << "dstrain12"
      << std::setw(20) << "dstrain13"
      << std::setw(20) << "dstrain23"
      << std::setw(20) << "sse"
      << std::setw(20) << "spd"
      << std::setw(20) << "scd"
      << std::setw(20) << "rpl"
      << std::setw(20) << "temp";
  for (int i=0; i<nstatev; ++i){
    ofs << std::setw(20) << std::string(histVarNames[i]);
  }
  ofs << std::endl;
  // Write the initial values:
  // Write the output:
  ofs << std::setw(20) << std::setprecision(12) << 0.0;
  for (int i=0; i<ntens; ++i){
    ofs << std::setw(20) << std::setprecision(12) << stress[i];
  }
  for (int i=0; i<ntens; ++i){
    ofs << std::setw(20) << std::setprecision(12) << strain[i];
  }
  for (int i=0; i<ntens; ++i){
    ofs << std::setw(20) << std::setprecision(12) << dstrain[i];
  }
  ofs << std::setw(20) << std::setprecision(12) << sse;
  ofs << std::setw(20) << std::setprecision(12) << spd;
  ofs << std::setw(20) << std::setprecision(12) << scd;
  ofs << std::setw(20) << std::setprecision(12) << rpl;
  ofs << std::setw(20) << std::setprecision(12) << temp;
  for(int i=0; i<nstatev; ++i){
    ofs << std::setw(20) << std::setprecision(12) << histVar[i];
  }
  ofs << std::endl;
  if(numStrainUnknown){
    double BC[6];
    unsigned int bcRef=0;
    std::vector<double> histVarTr(histVar);
    double stressTr[6];
    std::vector<double> stressTarget(numStrainUnknown, 0.0);
    std::vector<double> resVect(numStrainUnknown, 0.0);
    std::vector<double> delStrainInc(numStrainUnknown, 0.0);
    PTR::FastMatrix::FastMatrix dSdE(numStrainUnknown,numStrainUnknown);
    for (int step=0; step<nsteps; ++step){
      time[0] = step*delT;
      time[1] = (step+1)*delT;
      while((bcRef+1)<inputTime.size() && inputTime[bcRef+1]<=time[1]){
        ++bcRef;
      }
      BC[0] = BC11[bcRef];
      BC[1] = BC22[bcRef];
      BC[2] = BC33[bcRef];
      BC[3] = BC23[bcRef];
      BC[4] = BC13[bcRef];
      BC[5] = BC12[bcRef];
      for (int i=0; i<6; ++i){
        if (calcEpsComp[i] == 0) {
          dstrain[i] = i < 3 ? BC[i]*delT : 2.0*delT*BC[i];
        } else {
          dstrain[i] = 0.0;
        }
      }

      histVarTr=histVar;
      for (int i=0; i<6; ++i){
        stressTr[i] = stress[i];
      }
      double sseTr(sse), spdTr(spd), scdTr(scd), rplTr(rpl),
        tempTr(temp);
      PTR_umat_stressUpdate(stressTr, histVarTr.data(), ddsdde,
                            &sseTr, &spdTr, &scdTr, &rplTr,
                            ddsddt, drplde, &drpldt,
                            strain, dstrain, time,
                            &delT, &tempTr, &dtemp,
                            &predef, &dpred, &cmname,
                            &ndi, &nshr, &ntens, &nstatev,
                            matParam, &nprops, coords,
                            drot, &pnewdt, &celent,
                            dfgrd0, dfgrd0, &noel,
                            &npt, &layer, &kspt,
                            &kstep, &kinc
                            );
      double resMag(0.0);
      double targetMag(0.0);
      for (int m=0; m<numStrainUnknown; ++m){
        int i = calcEpsComIndex[m];
        stressTarget[m] = BC[i];
        resVect[m]      = stressTr[i] - stressTarget[m];
        resMag += resVect[m]*resVect[m];
        targetMag += stressTarget[m]*stressTarget[m];
        for (int n=0; n<numStrainUnknown; ++n){
          int j = calcEpsComIndex[n];
          dSdE(m,n) = ddsdde[i][j];
        }
      }

      PTR::FastMatrix::FastMatrix dSdE_inv(numStrainUnknown, numStrainUnknown);
      dSdE_inv.destructiveInvert(dSdE);

      const double relTol = 1.0e-8;
      const double absTol = 1.0e-12;
      const double strainTol = 1.0e-8;
      const int maxIter      = 1000;
      double delStrainMaxComp(1.0);
      int iter(0);
      while( !(resMag <= relTol*targetMag || resMag <= absTol || delStrainMaxComp <= strainTol) && iter < maxIter ){
        dSdE_inv.multiply(resVect, delStrainInc); 
        delStrainMaxComp =  0.0;
        for(int m=0; m<numStrainUnknown; ++m){
          int i = calcEpsComIndex[m];
          dstrain[i] -= delStrainInc[m];
          delStrainMaxComp = std::max(delStrainMaxComp, std::abs(delStrainInc[m]));
        }
        histVarTr=histVar;
        for (int i=0; i<6; ++i){
          stressTr[i] = stress[i];
        }
        sseTr = sse;
        spdTr = spd;
        scdTr = scd;
        rplTr = rpl;
        tempTr = temp;
        PTR_umat_stressUpdate(stressTr, histVarTr.data(), ddsdde,
                              &sseTr, &spdTr, &scdTr, &rplTr,
                              ddsddt, drplde, &drpldt,
                              strain, dstrain, time,
                              &delT, &tempTr, &dtemp,
                              &predef, &dpred, &cmname,
                              &ndi, &nshr, &ntens, &nstatev,
                              matParam, &nprops, coords,
                              drot, &pnewdt, &celent,
                              dfgrd0, dfgrd0, &noel,
                              &npt, &layer, &kspt,
                              &kstep, &kinc
                              );
        resMag = 0.0;
        for (int m=0; m<numStrainUnknown; ++m){
          int i = calcEpsComIndex[m];
          resVect[m]      = stressTr[i] - stressTarget[m];
          resMag += resVect[m]*resVect[m];
          for (int n=0; n<numStrainUnknown; ++n){
            int j = calcEpsComIndex[n];
            dSdE(m,n) = ddsdde[i][j];
          }
        }
        ++ iter;
        // std::cout << iter << "\t resMag:\t" << resMag
        //           << "\t relError:\t" << resMag/targetMag
        //           << "\t delStrainMaxComp:\t" << delStrainMaxComp
        //           << std::endl;
      } // end of iterations
      for (int i=0; i<ntens; ++i){
        strain[i] += dstrain[i];
        stress[i] = stressTr[i];
      }
      histVar=histVarTr;  
      sse = sseTr;
      spd = spdTr;
      scd = scdTr;
      rpl = rplTr;
      temp = tempTr;
    
      // Write the output:
      std::cout << "t=\t" << time[1] << "\t Number of Iterations: " << iter << std::endl;
      ofs << std::setw(20) << std::setprecision(12) << time[1];
      for (int i=0; i<ntens; ++i){
        ofs << std::setw(20) << std::setprecision(12) << stress[i];
      }
      for (int i=0; i<ntens; ++i){
        ofs << std::setw(20) << std::setprecision(12) << strain[i];
      }
      for (int i=0; i<ntens; ++i){
        ofs << std::setw(20) << std::setprecision(12) << dstrain[i];
      }
      ofs << std::setw(20) << std::setprecision(12) << sse;
      ofs << std::setw(20) << std::setprecision(12) << spd;
      ofs << std::setw(20) << std::setprecision(12) << scd;
      ofs << std::setw(20) << std::setprecision(12) << rpl;
      ofs << std::setw(20) << std::setprecision(12) << temp;
      for(int i=0; i<nstatev; ++i){
        ofs << std::setw(20) << std::setprecision(12) << histVar[i];
      }
      ofs << std::endl;
    }
  } else {
    double D[6];
    unsigned int velGradRef=0;
    for (int step=0; step<nsteps; ++step){
      time[0] = step*delT;
      time[1] = (step+1)*delT;
      while( (velGradRef+1)<inputTime.size() && inputTime[velGradRef+1]<=time[1] ){
        ++velGradRef;
      }
      D[0] = BC11[velGradRef];
      D[1] = BC22[velGradRef];
      D[2] = BC33[velGradRef];
      D[3] = BC23[velGradRef];
      D[4] = BC13[velGradRef];
      D[5] = BC12[velGradRef];
      dstrain[0] = D[0]*delT;
      dstrain[1] = D[1]*delT;
      dstrain[2] = D[2]*delT;
      dstrain[3] = 2.0*D[5]*delT;
      dstrain[4] = 2.0*D[4]*delT;
      dstrain[5] = 2.0*D[3]*delT;
      PTR_umat_stressUpdate(stress, histVar.data(), ddsdde,
                            &sse, &spd, &scd, &rpl,
                            ddsddt, drplde, &drpldt,
                            strain, dstrain, time,
                            &delT, &temp, &dtemp,
                            &predef, &dpred, &cmname,
                            &ndi, &nshr, &ntens, &nstatev,
                            matParam, &nprops, coords,
                            drot, &pnewdt, &celent,
                            dfgrd0, dfgrd0, &noel,
                            &npt, &layer, &kspt,
                            &kstep, &kinc
                            );
      for (int i=0; i<ntens; ++i){
        strain[i] += dstrain[i];
      }
      // Write the output:
      std::cout << "t=\t" << time[1] << std::endl;
      ofs << std::setw(20) << std::setprecision(12) << time[1];
      for (int i=0; i<ntens; ++i){
        ofs << std::setw(20) << std::setprecision(12) << stress[i];
      }
      for (int i=0; i<ntens; ++i){
        ofs << std::setw(20) << std::setprecision(12) << strain[i];
      }
      for (int i=0; i<ntens; ++i){
        ofs << std::setw(20) << std::setprecision(12) << dstrain[i];
      }
      ofs << std::setw(20) << std::setprecision(12) << sse;
      ofs << std::setw(20) << std::setprecision(12) << spd;
      ofs << std::setw(20) << std::setprecision(12) << scd;
      ofs << std::setw(20) << std::setprecision(12) << rpl;
      ofs << std::setw(20) << std::setprecision(12) << temp;
      for(int i=0; i<nstatev; ++i){
        ofs << std::setw(20) << std::setprecision(12) << histVar[i];
      }
      ofs << std::endl;
    }
  }

  for (int i=0; i<nstatev; ++i){
    delete [] histVarNames[i];
  }
  delete [] histVarNames;

  return 0;
}
