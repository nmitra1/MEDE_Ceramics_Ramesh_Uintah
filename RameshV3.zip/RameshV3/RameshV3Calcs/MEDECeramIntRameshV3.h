/*
 * This project constitutes a work of the United States Government and is not
 * subject to domestic copyright protection under 17 USC § 105.
 *
 * However, because the project utilizes code licensed from contributors and other
 * third parties, it therefore is licensed under the MIT License.
 * http://opensource.org/licenses/mit-license.php.
 *
 * Under that license, permission is granted free of charge, to any
 * person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the conditions that any
 * appropriate copyright notices and this permission notice are
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */


#ifndef MEDECeramIntRameshV3_H
#define MEDECeramIntRameshV3_H

#include "MGEOSMW.h"
#include "Vector3MW.h"
#include "Matrix3x3MW.h"
#include "IStateMW.h"
#include <cmath>
#include <vector>               // std::vector<double>

#include "GFMS_fullMW.h"          // GFMS::solParam GFMS::matParam
#include "IRTWM_defs.h"
namespace IRTWM                   // Portable TongeRamesh
{

  // Constants
  const double onethird = (1.0/3.0);
  const double sqtwthds = sqrt(2.0/3.0);

  struct Flags{
	bool implicit;
	bool useDamage;
	bool usePlasticity;
	bool useGranularPlasticity;
	bool with_color;
	bool useOldStress;
	bool artificialViscosity;
	bool artificialViscosityHeating;
        bool useAmorphization;
	
	// Erosion Algorithms
	bool doErosion;
	bool allowNoTension;
	bool allowNoShear;
	
	bool setStressToZero;
  };

  struct ArtificialViscosity{
	double coeff1;
	double coeff2;
  };

  // Create a datatype for the flaw distribution:
  struct flawDistributionData {
	int numCrackFamilies;     // Number of families to discritize the distribution into
	double meanFlawSize;      // Mean size of the flaws
	double flawDensity;       // Mean flaw density in the sample
	double stdFlawSize;       // Standard deviation of the flaw size
	std::string type;              // Type of the distribution (delta, normal, pareto)
	double minFlawSize;       // Minimum flaw for Pareto dist
	double maxFlawSize;       // Maximum flaw for Pateto dist
	double exponent;          // Exponent for Pateto dist
	bool   randomizeDist;     // Make each particle have a unique distribution
	int    randomSeed;        // Seed for random number generation
	int    randomMethod;      // Method for selecting bin size and location
	double binBias;           // Exponent for flaw distribution bin bias (1.0 for no bias)
	bool   useEtaField;       // Flag for using a fourier field to define the local flaw density
	std::string etaFilename;       // File name containing fourier data for flaw density
	bool   useSizeField;      // Flag for using a fourier field to define the local flaw size shift
	std::string sizeFilename;       // File name containing fourier data for flaw size
  };

  //Create datatype for brittle damage
  struct BrittleDamageData {
	bool printDamage;    /* Flag to print damage */

	// used for Bhasker's damage model:
	double KIc;               // Critical stress intensity factor
	double mu;                // Crack face friction coefficient
	double phi;               // angle between crack normal and max comp stress
	double cgamma;            // Exponent for crack growth speed
	double alpha;             // Multiplier for max crack velocity
	double criticalDamage;    // Damage level to start granular flow or mark as failed
	double maxDamage;         // Damage level to stop damage evolution
	// Use plane strain assumption for SCM calculation
	bool usePlaneStrain;

	// Control damage evolution timestepping:
	double maxDamageInc; /* Maximum damage increment in a time step */
	bool   useDamageTimeStep; // Control the global timestep with the damage timestep
	bool   useOldStress;      // Compute the damage based on the stress from the previous timestep
	double dt_increaseFactor;
	bool   incInitialDamage; // Include the initial flaw as a part of the damage level
	bool   doFlawInteraction; // do the ellipse calculation for flaw interactions
  };
 
  //Create datatype for amorphization
  struct AmorphizationData {	
	
        double xi_c;    //Reference rate
        double m;       //rate sensitivity, m->oo, rate independent
        double eta_a;   //Density change ratio

        double Fa0;     //Initial threshold
        double alpha0;  //Shear-enhancement coefficient
        double Fac;     //Completion pressure

        double tau0;        //Initial shear resistance
        double mu_band;     //Viscosity of amorphous phase
        double gamma_band_c; //Critical failure strain

        double k_a;       //Parameter for flaw density
        double n_a;       //Parameter for flaw density
        double Gc;        //Energy dissipation rate per band
        
        //EOS parameters for the amorphous phase
        //For BC, we have assumed the same values as the crystalline phase.
        double C_0_a;    
        double Gamma_0_a; 
        double S_1_a;     
        double C_v_a;
        double theta_0_a;  
        double shearModulus_a;      
  }; 
  

  typedef enum GPModel {TwoSurface, SingleSurface,BreakageModel} GPModel;
  struct granularPlasticityData {
	double timeConstant;      // Time constant for viscoplastic update (0 is rate independent)
	double JGP_loc;           // Value of JGP to trigure localized particles

	// Parameters that define the Granular plastic yeild surface:
	double A;                 // Damaged scale parameter
	double B;                 // Damaged hydrostatic tensile strength
	int    yeildSurfaceType;  // 1 for cone with hemispherical cap, 2 for parabola

	// P-alpha compaction model parameters:
	double Pc;                // Pressure (+ compression) for full compaction
	double alpha_e;           // Distension corrisponding to elastic compaction pressure
	double Pe;                // Pressure required to start compaction at J^{GP}=\alpha_e
    GPModel GPModelType;        // TwoSurface for the original implimentation, SingleSurface for the
    // new and imporved model.
    GFMSMW::solParam GFMSsolParams;
    GFMSMW::matParam GFMSmatParams;

    // Breakage model
   GFMSMW::IndexParamBM GFMSIndexParamsBM;
   GFMSMW::MatParamBM GFMSMatParamsBM;

  };

  // Create datatype for storing model parameters
  struct ModelData {
    double Bulk;
    double tauDev;
    double rho_orig;
    // For Plasticity
    //double FlowStress;
    double K;
    double Alpha;
    double timeConstant;
  	double FlowStress;
	double HardeningParameter;
	double InitialPlasticStrain;
	double UltimateFlowStress;
	double RateSensitivity;
	double ViscosityParameter;
  };

  void computeIncStress(	const BrittleDamageData brittle_damage,
                            const double eta3d,
                            const double matrixStress[2],
                            double incStress[3],
                            const double wingDamage,
                            const double parentDamage,
                            const IStateMW state);

  double calculateDamageGrowth(	const BrittleDamageData brittle_damage,
                                const Matrix3x3MW stress,
                                const double N[],
                                const double s[],
                                const double old_L[],
                                const double currentDamage,
                                double new_L[],
                                double new_Ldot[],
                                const double dt,
                                const int Localized,
                                const IStateMW state,
                                const int nBins,
                                double new_KIc
                                );
  
  void calcAmorphization(const AmorphizationData amorphizationData, 
                         const Matrix3x3MW pStress_old,
                         const double delT,
                         const double J_old,
                         const double J,
                         const double rho_orig,
                         const IStateMW state,
                         const Matrix3x3MW pDeformRate,
                         Matrix3x3MW Rinc,
                         Matrix3x3MW Fa_old,                         
                         Matrix3x3MW Feg_old, 
                         double pDamage_old,
                         double criticalDamage,
                         Matrix3x3MW *pFa,//deformation gradient induced by amorphization                              
                         std::vector<double> *band_orientation,
                         std::vector<double> *xi,
                         std::vector<double> *gamma_band,
                         double *pGamma_shear,                         
                         double *pDamage_a,
                         double *pAmorphized,
                         double *pAmorph_energy,          
                         double *pdTdt_out
                         );
      
      
  
  void calcGranularFlow( const Flags flags, // input flags
                         const BrittleDamageData brittle_damage, // Damage flags
                         const granularPlasticityData gpData,
                         const MGEOSMW *eos, // passed through to computePressure
                         const double delT,
                         const double pDamage_new,
                         const double pDamage_total,
                         const double J,
                         const double pGPJ_old,
                         Matrix3x3MW *bElBar_new, // Input and output (deviatoric elastic strain)
                         IStateMW *state,
                         double *pGPJ,
                         double *pGP_strain,
                         double *pGP_energy,
                         double *pdTdt
                         );
  
  double computePressure(const MGEOSMW *eos, 
                         const Matrix3x3MW F, 
                         const IStateMW state, 
                         const double currentDamage
                         );

  double calculateBulkPrefactor( const double currentDamage, 
                                 const IStateMW state,
                                 const double J = 1.0
                                 );

  double calculateShearPrefactor(	const double currentDamage, 
                                    const IStateMW state
                                    );

  double calc_yeildFunc_g_gs_gp(	const granularPlasticityData gpData,
                                    const double sigma_s,
                                    const double sigma_p,
                                    double *gs, 
                                    double *gp);

  double artificialBulkViscosity(	const double Dkk, 
                                    const double c_bulk, 
                                    const double rho,
                                    const double dx,
                                    const ArtificialViscosity av
                                    );

  double computeStableTimestep(	const ModelData initialData,
                                const Vector3MW pVelocity,
                                const Vector3MW dx,
                                const double pMass,
                                const double pVolume);
								
  void ComputeStressTensorInnerLoop(
                                    // Data Structures
                                    const Flags flags,
                                    const ModelData initialData,
                                    const flawDistributionData flawDistData,
                                    const BrittleDamageData brittle_damage,
                                    const AmorphizationData amorphizationData,
                                    const granularPlasticityData gpData,
                                    const ArtificialViscosity artificialViscosity,
                                    const MGEOSMW *eos,
                
                                    // Input Matrices
                                    const Matrix3x3MW pDefGrad,
                                    const Matrix3x3MW pDefGrad_new,
                                    const Matrix3x3MW pVelGrad,

                                    // Output Matrix
                                    Matrix3x3MW *pDeformRate,
                                    Matrix3x3MW *bElBar,
                                    Matrix3x3MW *pStress,
                                    Matrix3x3MW *pStress_qs,

                                    // Input Vector3MW
                                    const Vector3MW pVelocity,
                                    const Vector3MW dx,

                                    // Output Vector3MW
                                    Vector3MW *WaveSpeed,

                                    // Input double
                                    const double pGPJ_old,
                                    const double RoomTemperature,
                                    const double pTemperature,
                                    const double rho_orig,
                                    const double pVolume_new,
                                    const double pMass,
                                    const double SpecificHeat,
                                    const double pDamage,
                                    const double K,
                                    const double flow,
                                    const double delT,
                
                                    // Output double
                                    double *pGP_strain,
                                    double *pPlasticStrain,
                                    double *pPlasticEnergy,
                                    double *pDamage_new,
                                    double *pGPJ,
                                    double *pGP_energy,
                                    double *pEnergy_new,
                                    double *damage_dt,
                                    double *p_q,
                                    double *se,
                                    double *pdTdt,
                                    double *pepsV,
                                    double *pgam,
                                    double *pepsV_qs,
                                    double *pgam_qs,
                                    double *pD_energy, 
                                    double *pMPStatus,

                                    // Input int
                                    const int pLocalized,
                                    const long long pParticleID,
                
                                    // Output int
                                    long long *totalLocalizedParticle,
                                    int *pLocalized_new,
                
                                    // Input std::vector
                                    const std::vector<double> *pWingLength_array,
                                    const std::vector<double> *pFlawNumber_array,
                                    const std::vector<double> *pflawSize_array,

                                    // Output std::vector
                                    std::vector<double> *pWingLength_array_new,
                                    //amorphization, Input and Output                                    
                                    Matrix3x3MW *pFa,//deformation gradient induced by amorphization
                                    double *pDamage_a,
                                    //double *pEta_a,
                                    //double *pGamma_a,         
                                    std::ofstream &amorphization,
				                            double *pporosity,
			                              double *pB          
                                    );

  void advanceTimeSigmaL(
                         // Data Structures
                         const Flags flags,
                         const ModelData initialData,
                         const flawDistributionData flawDistData,
                         const BrittleDamageData brittle_damage,
                         const AmorphizationData amorphizationData,
                         const granularPlasticityData gpData,
                         const ArtificialViscosity artificialViscosity,
                         const MGEOSMW *eos,
                         // Input Matrix:
                         const Matrix3x3MW velGrad,
                         // Input/OutputMatrix:
                         Matrix3x3MW *pStress,
                         Matrix3x3MW *pStress_qs,
                         // Input double
                         const double delT,
                         const double J_old,
                         const double J,
                         const double pTemperature,
                         const double rho_orig,
                         const double dx_ave, /* mean spatial dimension for art visc calc */
                         // Input/Output double
                         double *pIEl,
                         double *pPlasticStrain,
                         double *pPlasticEnergy,
                         double *pDamage,
                         double *pGPJ,
                         double *pGP_strain,
                         double *pGP_energy,
                         double *pEnergy,
                         double *damage_dt,
                         double *pepsV,
                         double *pgam,
                         double *pepsV_qs,
                         double *pgam_qs,
                         int *pLocalized,
                         // Output only double:
                         double *p_q_out,
                         double *pdTdt_out,
                         double *c_dil_out,
                         // Input std::vector
                         const std::vector<double> *pWingLength_array,
                         const std::vector<double> *pFlawNumber_array,
                         const std::vector<double> *pflawSize_array,
                         // Output std::vector
                         std::vector<double> *pWingLength_array_new,
                         //amorphization, Input and Output
                         Matrix3x3MW *pF,//deformation gradient 
                         Matrix3x3MW *pFinc,//deformation gradient increment
                         Matrix3x3MW *pRinc,//rotation increment
                         Matrix3x3MW *pFa,//deformation gradient induced by amorphization
                         std::ofstream &amorphization,
                         std::vector<double> *band_orientation,
                         std::vector<double> *xi,
                         std::vector<double> *gamma_band,
                         double *pGamma_shear,                         
                         double *pDamage_shear,
                         double *pAmorphized,
                         double *pAmorph_energy,
			                   double *pTempV,
                         double *pD_energy, 
                         double *pMPStatus,
                         const int subroutine,
			                   double *pporosity,
			                   double *pB,
                         const bool assumeRotatedTensors=false
                         );

  void postAdvectionFixup(
                          // Data Structures
                          const Flags flags,
                          const ModelData initialData,
                          const flawDistributionData flawDistData,
                          const BrittleDamageData brittle_damage,
                          const AmorphizationData  amorphizationData,
                          const granularPlasticityData gpData,
                          const ArtificialViscosity artificialViscosity,
                          const MGEOSMW *eos,
                          // Input/OutputMatrix:
                          Matrix3x3MW *pStress, // Recalculate
                          Matrix3x3MW *pStress_qs, // Unused
                          const double J,        // input
                          const double pTemperature, // input
                          const double rho_orig,     // input
                          // Input/Output double
                          double *pIEl, // update
                          double *pPlasticStrain, // Unused
                          double *pPlasticEnergy, 
                          double *pDamage,
                          double *pGPJ,
                          double *pGP_strain,
                          double *pGP_energy,
                          double *pEnergy,
                          double *damage_dt,
                          double *pepsV,
                          double *pgam,
                          double *pepsV_qs,
                          double *pgam_qs,
                          int *pLocalized,
                          // Input/Output std::vector
                          std::vector<double> *pWingLength_array,
                          std::vector<double> *pFlawNumber_array,
                          std::vector<double> *pflawSize_array
                          );


  std::string getHistVarName(const int histVarNum);
  std::string getMatParamName(const int paramNumber);
  void parseFlawDistData(double flawDistParam[IRTWM_NUM_FLAW_DIST_PARAM],
                         const std::string inputFileName);
  void parseMatParamData(double matParam[IRTWM_NUM_MAT_PARAMS],
                         const std::string inputFileName);

  void unpackMatParams(const double matParamArray[IRTWM_NUM_MAT_PARAMS],
                       Flags *flags,
                       ModelData *initialData,
                       flawDistributionData *flawDistData,
                       BrittleDamageData *brittle_damage,
                       AmorphizationData *amorphizationData,
                       granularPlasticityData *gpData,
                       ArtificialViscosity *artificialViscosity,
                       CMData *eosData
                       );
  flawDistributionData unpackFlawDistData( const double flawDistArray[IRTWM_NUM_FLAW_DIST_PARAM]);
  double initalizeFlawDist( double flawSize[],
                            double flawNumber[],
                            const flawDistributionData flawDistData,
                            const double dx_ave, unsigned long seedArray[],
                            unsigned long nSeedValues
                            );
}	// end namespace IRTWM

#endif /* MEDECeramIntRameshV3_H */ 
