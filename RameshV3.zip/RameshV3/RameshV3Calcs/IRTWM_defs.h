/*
 * This project constitutes a work of the United States Government and is not
 * subject to domestic copyright protection under 17 USC 搂 105.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

#ifndef IRTWM_DEFS_H
#define IRTWM_DEFS_H

//#define NDEBUG

#define IRTWM_NUM_MAT_PARAMS 110
#define IRTWM_NUM_SCALAR_ISV 72 //originally it was 14 and Qinglei adds params for amorphization 9Fa+9F+18orientation+6xi+6gamma+shear+damage+ifamorphi+energy+temp+ Weixin add 2+Mehmet add 2
#define IRTWM_NUM_TENS_ISV 1
#define IRTWM_FLAWHIST_OFFSET (IRTWM_NUM_SCALAR_ISV + 6*IRTWM_NUM_TENS_ISV)
#define IRTWM_NUM_FLAW_DIST_PARAM 12
#define IRTWM_NUM_FLAW_HIST_PARAM 3
#define IRTWM_BULKMOD_IDX 6
#define IRTWM_SHEARMOD_IDX 7
#define IRTWM_DESITY_IDX 8
#define IRTWM_LOCALIZED_IDX 9
#define IRTWM_NUM_FLAW_BIN_IDX 13
const char * const IRTWM_MatParamNames[IRTWM_NUM_MAT_PARAMS] = {
  "useDamage",
  "usePlasticity",
  "useGranularPlasticity",
  "useOldStress",
  "artificialViscosity",
  "artificialViscousHeating",
  "BulkModulus",
  "ShearModulus",
  "rho_orig",
  "FlowStress",
  "HardeningParameter",
  "InitialPlasticStrain",
  "UltimateFlowStress",
  "NumCrackFamilies",
  "MeanFlawSize",
  "FlawDensity",
  "StdFlawSize",
  "FlawDistType",
  "MinFlawSize",
  "MaxFlawSize",
  "FlawDistExponent",
  "RandomizeFlawDist",
  "RandomSeed",
  "RandomizeMethod",
  "BinBias",
  "KIc",
  "FlawFriction",
  "FlawAngle",
  "FlawGrowthExponent",
  "FlawGrowthAlpha",
  "CriticalDamage",
  "MaxDamage",
  "MicroMechPlaneStrain",
  "MaxDamageInc",               /* Remove? */
  "UseDamageTimestep",          /* Remove */
  "dt_increaseFactor",          /* Remove */
  "IncInitDamage",
  "DoFlawInteraction",
  "GPTimeConst",
  "JLoc",
  "GPGranularSlope",
  "GPCohesion",
  "GPYieldSurfType",            /* Merge with 46? */
  "GPPc",
  "GPJref",
  "GPPref",
  "GPSurfaceType",              /* 0-Two surface, 1- Single surface, 2- Breakage Cil */
  "AbsToll",
  "RelToll",
  "MaxIter",
  "MaxLevels",
  "GFMSm0",
  "GFMSm1",
  "GFMSm2",
  "GFMSp0",
  "GFMSp1",
  "GFMSp2",
  "GFMSp3",
  "GFMSp4",
  "GFMSa1",
  "GFMSa2",
  "GFMSa3",
  "GFMSBeta",
  "GFMSPsi",
  "GFMSJ3Type",
  "ArtVisc1",
  "ArtVisc2",
  "MGC0",
  "MGGamma0",
  "MGS1",
  "MGS2",
  "MGS3",
  "MGCv",
  "MGTheta_0",
  "JMin",                       /* Remove */
  "MGNPts",                      /* Remove */
  "useAmorphization",
  "ReferenceRate",
  "RateCoefficient",
  "DensityChange",
  "Fa0",
  "Alpha",
  "Fac",
  "ShearResist",
  "ViscosityAmorph",
  "BandFailStrain",
  "FailBandDensity1",
  "FailBandDensity2", 
  "BandEnergyDissip",
  "MGC0_A",
  "MGGamma0_A",
  "MGS1_A",
  "MGCv_A", 
  "MGTheta_0_A",
  "ShearModulus_A",
  "RateSensitivity",                     /*Weixin Add */
  "ViscosityParameter",                /* Weixin Add */
  "GPB_Ec",
  "GPB_kappa",
  "GPB_Mcs",
  "GPB_gammaB",
  "GPB_gamma",
  "GPB_theta",
  "GPB_eta",
  "GPB_Nvp",
  "GPB_por_u",
  "GPB_por_l",
  "GPB_porind_u",
  "GPB_porind_l",
  "GPB_por0"
};

const char * const IRTWM_FlawDistParamNames[IRTWM_NUM_FLAW_DIST_PARAM] = {
  "NumCrackFamilies",
  "MeanFlawSize",
  "FlawDensity",
  "StdFlawSize",
  "FlawDistType",
  "MinFlawSize",
  "MaxFlawSize",
  "FlawDistExponent",
  "RandomizeFlawDist",
  "RandomSeed",
  "RandomizeMethod",
  "BinBias"
};

/* The vector of history variables consists of two parts, a fixed length portion
   representing the variable names in IRTWM_StateVarNames followed by a variable
   length portion that contains the flaw distribution and wing crack growth
   information. This variable length portion has the ordering shown in
   IRTWM_FlawDistStateBaseNames*/
const char * const IRTWM_StateVarNames[IRTWM_FLAWHIST_OFFSET] = {
  "Iel",
  "damage",
  "JGP",
  "GP_strain",
  "GP_energy",
  "plasticStrain",
  "plasticEnergy",
  "artViscPres",
  "LongitudinalVel",
  "localized",
  "epsVGP",
  "gamGP",
  "epsVGP_qs",
  "gamGP_qs",
  "sig_qs_11",
  "sig_qs_22",
  "sig_qs_33",
  "sig_qs_23",
  "sig_qs_13",
  "sig_qs_12",
  "Fa11",
  "Fa12",
  "Fa13",
  "Fa21",
  "Fa22",
  "Fa23",
  "Fa31",
  "Fa32",
  "Fa33",
  "F11",
  "F12",
  "F13",
  "F21",
  "F22",
  "F23",
  "F31",
  "F32",
  "F33",
  "n1x",
  "n1y",
  "n1z",
  "n2x",
  "n2y",
  "n2z",
  "n3x",
  "n3y",
  "n3z",
  "n4x",
  "n4y",
  "n4z",
  "n5x",
  "n5y",
  "n5z",
  "n6x",
  "n6y",
  "n6z",
  "xi_1",
  "xi_2",
  "xi_3",
  "xi_4",
  "xi_5",
  "xi_6",
  "gamma_band_1",
  "gamma_band_2",
  "gamma_band_3",
  "gamma_band_4",
  "gamma_band_5",
  "gamma_band_6",  
  "gamma_shear",
  "damage_shear",
  "amorphized",
  "amorphEnergy",
  "Total_xi",
  "Temperature",
  "D_energy",
  "MPStatus",
  "GP_porosity",
  "GP_B"  
};

const char * const IRTWM_FlawDistStateBaseNames[IRTWM_NUM_FLAW_HIST_PARAM] = {
  "flawNumber",
  "starterFlawSize",
  "wingLength"
};

#endif // end ifdef IRTWM_DEFS_H
